import { defineConfig, splitVendorChunkPlugin } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
  },

  plugins: [
    react(),
    splitVendorChunkPlugin(),
    mode === "development" && componentTagger(),
  ].filter(Boolean),

  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },

  build: {
    // Target modern browsers for smaller output
    target: "es2020",

    // Warn if any chunk exceeds 500 kB
    chunkSizeWarningLimit: 500,

    // Enable source maps for production error reporting (e.g. Sentry)
    sourcemap: true,

    rollupOptions: {
      output: {
        // Manual chunking — vendor libs are split so unchanged code
        // isn't re-downloaded on every app update
        manualChunks: {
          "vendor-react": ["react", "react-dom", "react-router-dom"],
          "vendor-radix": [
            "@radix-ui/react-dialog",
            "@radix-ui/react-dropdown-menu",
            "@radix-ui/react-toast",
            "@radix-ui/react-tabs",
            "@radix-ui/react-select",
            "@radix-ui/react-alert-dialog",
          ],
          // Map is ~2 MB — isolate it so other code changes don't bust this cache
          "vendor-mapbox": ["mapbox-gl"],
          "vendor-query": ["@tanstack/react-query"],
          "vendor-supabase": ["@supabase/supabase-js"],
          "vendor-motion": ["framer-motion"],
          "vendor-utils": ["date-fns", "zod", "clsx", "tailwind-merge", "class-variance-authority"],
        },
      },
    },
  },

  // Speed up cold-start in dev
  optimizeDeps: {
    include: [
      "react",
      "react-dom",
      "react-router-dom",
      "@supabase/supabase-js",
      "@tanstack/react-query",
      "mapbox-gl",
      "framer-motion",
    ],
  },
}));
