# Spirit Shield Keeper

A real-time, community-driven emergency safety app built for Namibia.

## Features

- **Panic Button** — One-tap emergency alert with GPS, audio recording, and live watcher tracking
- **Live Safety Map** — Real-time incident heatmap powered by Mapbox GL; community-reported threats visible instantly
- **Look After Me** — Share a live trip with trusted watchers; auto-escalates if you don't check in
- **Amber Alerts** — Community BOLO system with dedicated chat rooms per alert
- **Community Feed** — Neighbourhood safety posts with keyword-triggered incident reports
- **Authorities Panel** — Direct-dial panel for emergency services
- **Safety Dashboard** — Credibility scoring, achievements, and historical activity

## Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18 + TypeScript + Vite |
| Styling | Tailwind CSS + shadcn/ui + Radix UI |
| Data / Auth | Supabase (PostgreSQL + Realtime + Edge Functions) |
| Maps | Mapbox GL JS v3 |
| State | TanStack Query v5 |
| Animation | Framer Motion |

## Getting Started

### Prerequisites

- Node.js 18+ (or Bun)
- A [Supabase](https://supabase.com) project
- A [Mapbox](https://mapbox.com) account (token stored as a Supabase secret)

### Local Development

```bash
# 1. Clone
git clone https://github.com/your-org/spirit-shield-keeper.git
cd spirit-shield-keeper

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env
# Edit .env — add your Supabase URL + anon key

# 4. Start dev server
npm run dev
```

The app runs at `http://localhost:8080`.

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `VITE_SUPABASE_URL` | ✅ | Your Supabase project URL |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | ✅ | Supabase anon/public key |
| `VITE_SUPABASE_PROJECT_ID` | Optional | Project ID (used for deep links) |

> The Mapbox token is fetched at runtime via the `get-mapbox-token` Edge Function. Store it as a Supabase secret — never put it in `.env`.

### Database Setup

```bash
supabase db push
```

Or apply migrations in order from `supabase/migrations/`.

## Scripts

```bash
npm run dev          # Dev server with HMR
npm run build        # Type-check + production build
npm run type-check   # TypeScript check only (fast)
npm run lint         # ESLint (zero warnings enforced)
npm run preview      # Preview the production build locally
```

## Deployment

### Netlify / Vercel (recommended)

1. Connect your repository.
2. Add the env vars from `.env.example` in the dashboard.
3. Build command: `npm run build` | Publish directory: `dist`
4. Add a rewrite rule: `/*` → `/index.html` (required for SPA routing).

### Self-hosted (nginx)

```nginx
server {
  listen 80;
  root /var/www/spirit-shield/dist;
  index index.html;

  location / {
    try_files $uri $uri/ /index.html;
  }

  # Vite hashes asset filenames — cache them forever
  location ~* \.(js|css|woff2|png|ico)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
  }
}
```

## Supabase Edge Functions

| Function | Purpose |
|----------|---------|
| `get-mapbox-token` | Returns Mapbox token from secrets (not exposed to client) |
| `panic-session` | Creates/updates panic sessions and notifies watchers |
| `send-push-notification` | Sends Web Push via VAPID |
| `send-incident-notification` | Broadcasts incident alerts to nearby users |
| `open-emergency-api` | Proxies external emergency service APIs |

Deploy all functions: `supabase functions deploy`

## Architecture

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the full system diagram.

## Contributing

1. Fork and create a feature branch: `git checkout -b feat/my-feature`
2. Ensure `npm run type-check` and `npm run lint` both pass
3. Open a pull request against `main`

## License

MIT
