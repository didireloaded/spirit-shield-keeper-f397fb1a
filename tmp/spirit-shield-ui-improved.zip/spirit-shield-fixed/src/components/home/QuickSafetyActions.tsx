/**
 * Quick Safety Actions Widget
 * Quick access buttons for emergency features on the home screen
 */

import { motion } from 'framer-motion';
import { Shield, MapPin, Users, AlertTriangle, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function QuickSafetyActions() {
  const navigate = useNavigate();

  const actions = [
    {
      icon: AlertTriangle,
      label: 'Report',
      description: 'Incident',
      color: 'text-destructive',
      bg: 'bg-destructive/10',
      onClick: () => navigate('/map'),
    },
    {
      icon: MapPin,
      label: 'Live Map',
      description: 'View area',
      color: 'text-primary',
      bg: 'bg-primary/10',
      onClick: () => navigate('/map'),
    },
    {
      icon: Users,
      label: 'Watchers',
      description: 'My circle',
      color: 'text-blue-400',
      bg: 'bg-blue-500/10',
      onClick: () => navigate('/watchers'),
    },
    {
      icon: Heart,
      label: 'Safety',
      description: 'Dashboard',
      color: 'text-success',
      bg: 'bg-success/10',
      onClick: () => navigate('/safety'),
    },
  ];

  return (
    <div className="grid grid-cols-4 gap-2">
      {actions.map((action, index) => (
        <motion.button
          key={action.label}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.06, type: "spring", stiffness: 300 }}
          whileTap={{ scale: 0.94 }}
          onClick={action.onClick}
          className={`flex flex-col items-center gap-2 p-3 rounded-2xl border border-border/40 bg-card transition-colors active:opacity-80`}
        >
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${action.bg}`}>
            <action.icon className={`w-4.5 h-4.5 ${action.color}`} />
          </div>
          <div className="text-center">
            <p className="text-[11px] font-semibold leading-none" style={{ fontFamily: "'Outfit', sans-serif" }}>{action.label}</p>
            <p className="text-[9px] text-muted-foreground mt-0.5">{action.description}</p>
          </div>
        </motion.button>
      ))}
    </div>
  );
}
