import { motion } from "framer-motion";
import { MessageCircle, Shield, SlidersHorizontal } from "lucide-react";
import { Link } from "react-router-dom";
import { NotificationBell } from "./NotificationBell";

interface HeaderProps {
  title?: string;
}

export const Header = ({ title }: HeaderProps) => {
  return (
    <header
      className="sticky top-0 z-40 border-b border-border/60"
      style={{ background: "hsl(240 10% 4% / 0.92)", backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)" }}
    >
      <div className="flex items-center justify-between h-14 px-4 max-w-lg mx-auto">
        {/* Left: DM Icon */}
        <Link
          to="/messages"
          className="w-9 h-9 rounded-xl flex items-center justify-center hover:bg-secondary transition-colors"
          aria-label="Messages"
        >
          <MessageCircle className="w-5 h-5 text-muted-foreground" strokeWidth={1.8} />
        </Link>

        {/* Center: Logo */}
        <Link to="/" className="flex items-center gap-2.5">
          <motion.div
            whileHover={{ rotate: 12, scale: 1.05 }}
            transition={{ type: "spring", stiffness: 400, damping: 15 }}
            className="w-8 h-8 rounded-xl gradient-guardian flex items-center justify-center shadow-guardian"
          >
            <Shield className="w-[18px] h-[18px] text-white" strokeWidth={2.2} />
          </motion.div>
          <span
            className="font-bold text-lg tracking-tight text-gradient-guardian"
            style={{ fontFamily: "'Outfit', sans-serif" }}
          >
            {title || "Spirit Shield"}
          </span>
        </Link>

        {/* Right: Notifications & Settings */}
        <div className="flex items-center gap-0.5">
          <NotificationBell />
          <Link
            to="/settings/notifications"
            className="w-9 h-9 rounded-xl flex items-center justify-center hover:bg-secondary transition-colors"
            aria-label="Settings"
          >
            <SlidersHorizontal className="w-5 h-5 text-muted-foreground" strokeWidth={1.8} />
          </Link>
        </div>
      </div>
    </header>
  );
};
