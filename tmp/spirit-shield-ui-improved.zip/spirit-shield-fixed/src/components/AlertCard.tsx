import { motion } from "framer-motion";
import { AlertTriangle, Search, MapPin, Clock, ChevronRight } from "lucide-react";

export type AlertType = "panic" | "amber" | "robbery" | "suspicious" | "assault" | "accident" | "other" | "safe";

interface AlertCardProps {
  type: AlertType;
  title: string;
  location: string;
  time: string;
  distance?: string;
  isNew?: boolean;
}

const alertStyles: Record<AlertType, { bg: string; icon: string; label: string; accent: string }> = {
  panic: {
    bg: "bg-destructive/8 border-destructive/20",
    icon: "bg-destructive/15 text-destructive",
    label: "Panic",
    accent: "bg-destructive",
  },
  amber: {
    bg: "bg-warning/8 border-warning/20",
    icon: "bg-warning/15 text-warning",
    label: "Amber Alert",
    accent: "bg-warning",
  },
  robbery: {
    bg: "bg-destructive/8 border-destructive/20",
    icon: "bg-destructive/15 text-destructive",
    label: "Robbery",
    accent: "bg-destructive",
  },
  suspicious: {
    bg: "bg-warning/8 border-warning/20",
    icon: "bg-warning/15 text-warning",
    label: "Suspicious",
    accent: "bg-warning",
  },
  assault: {
    bg: "bg-destructive/8 border-destructive/20",
    icon: "bg-destructive/15 text-destructive",
    label: "Assault",
    accent: "bg-destructive",
  },
  accident: {
    bg: "bg-orange-500/8 border-orange-500/20",
    icon: "bg-orange-500/15 text-orange-400",
    label: "Accident",
    accent: "bg-orange-500",
  },
  other: {
    bg: "bg-secondary/60 border-border",
    icon: "bg-secondary text-secondary-foreground",
    label: "Other",
    accent: "bg-muted",
  },
  safe: {
    bg: "bg-success/8 border-success/20",
    icon: "bg-success/15 text-success",
    label: "All Clear",
    accent: "bg-success",
  },
};

export const AlertCard = ({
  type,
  title,
  location,
  time,
  distance,
  isNew,
}: AlertCardProps) => {
  const style = alertStyles[type] || alertStyles.other;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      whileTap={{ scale: 0.99 }}
      className={`
        relative overflow-hidden rounded-2xl border cursor-pointer
        transition-all duration-200 active:opacity-90
        ${style.bg}
      `}
    >
      {/* Left accent stripe */}
      <div className={`absolute left-0 top-0 bottom-0 w-1 ${style.accent}`} />

      <div className="flex items-start gap-3 p-4 pl-5">
        {/* Icon */}
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${style.icon}`}>
          {type === "amber" ? (
            <Search className="w-4.5 h-4.5" />
          ) : (
            <AlertTriangle className="w-4.5 h-4.5" />
          )}
        </div>

        <div className="flex-1 min-w-0">
          {/* Type label + Active badge */}
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest">
              {style.label}
            </span>
            {isNew && (
              <span className="px-1.5 py-px text-[9px] font-bold uppercase bg-destructive text-white rounded-full tracking-wide">
                Active
              </span>
            )}
          </div>

          {/* Title */}
          <h3 className="font-semibold text-sm leading-snug line-clamp-2 text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>
            {title}
          </h3>

          {/* Location + time row */}
          <div className="flex items-center gap-3 mt-2">
            <div className="flex items-center gap-1 text-muted-foreground min-w-0">
              <MapPin className="w-3 h-3 flex-shrink-0" />
              <span className="text-xs truncate">{location}</span>
            </div>
            {distance && (
              <span className="text-[11px] px-2 py-0.5 bg-background/50 border border-border/50 rounded-full text-muted-foreground flex-shrink-0">
                {distance}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 mt-1.5 text-muted-foreground/70">
            <Clock className="w-3 h-3" />
            <span className="text-[11px]">{time}</span>
          </div>
        </div>

        <ChevronRight className="w-4 h-4 text-muted-foreground/50 flex-shrink-0 mt-1" />
      </div>
    </motion.div>
  );
};
