/**
 * useVoiceRoom — stable, named rooms, one per user.
 * leaveInternal declared BEFORE join to avoid hoisting bugs.
 */
import { useCallback, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useStore } from "@/store";

declare global {
  interface Window {
    DailyIframe: { createCallObject: (opts?: object) => DailyCallObject }
  }
}
interface DailyCallObject {
  join:         (opts: { url: string; startVideoOff?: boolean; startAudioOff?: boolean }) => Promise<void>;
  leave:        () => Promise<void>;
  destroy:      () => Promise<void>;
  on:           (event: string, cb: (e: any) => void) => DailyCallObject;
  off:          (event: string, cb: (e: any) => void) => DailyCallObject;
  participants: () => Record<string, unknown>;
}

let dailyCall: DailyCallObject | null = null;

function createDailyCall(): DailyCallObject {
  if (!dailyCall) {
    if (!window.DailyIframe) throw new Error("Daily.co SDK not loaded.");
    dailyCall = window.DailyIframe.createCallObject({ audioSource: true, videoSource: false });
  }
  return dailyCall;
}

async function clearOldRooms(userId: string) {
  await supabase.from("voice_rooms")
    .update({ is_active: false })
    .eq("created_by", userId)
    .eq("is_active", true);
}

export function useVoiceRoom() {
  const voiceActive       = useStore((s) => s.voiceActive);
  const voiceRoomName     = useStore((s) => s.voiceRoomName);
  const voiceParticipants = useStore((s) => s.voiceParticipants);
  const setVoiceRoom      = useStore((s) => s.setVoiceRoom);
  const leaveVoiceRoom    = useStore((s) => s.leaveVoiceRoom);
  const setParticipants   = useStore((s) => s.setVoiceParticipants);
  const showNotif         = useStore((s) => s.showNotification);

  // Participant count sync
  useEffect(() => {
    if (!voiceActive || !dailyCall) return;
    const count = () => {
      try { setParticipants(Object.keys(dailyCall!.participants()).length); } catch {}
    };
    dailyCall
      .on("participant-joined",  count)
      .on("participant-left",    count)
      .on("participant-updated", count);
    count();
    return () => {
      dailyCall?.off("participant-joined", count)
               .off("participant-left",    count)
               .off("participant-updated", count);
    };
  }, [voiceActive, setParticipants]);

  // ── leaveInternal must be above join ──────────────────────────────
  const leaveInternal = async () => {
    try {
      if (dailyCall) {
        await dailyCall.leave();
        await dailyCall.destroy();
        dailyCall = null;
      }
      const { data: { user } } = await supabase.auth.getUser();
      if (user) await clearOldRooms(user.id);
    } catch (err) {
      console.error("leave error:", err);
    } finally {
      leaveVoiceRoom();
      showNotif("🔕 Left voice room", "warning");
    }
  };

  const join = useCallback(async () => {
    // Toggle: tap while active → leave
    if (voiceActive) { await leaveInternal(); return; }

    try {
      showNotif("🎙 Connecting…", "success");

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { showNotif("❌ Sign in required", "error"); return; }

      const { data: profile } = await supabase
        .from("profiles").select("display_name").eq("user_id", user.id).maybeSingle();

      const name = profile?.display_name || user.email?.split("@")[0] || "Driver";
      await clearOldRooms(user.id);

      const { data, error } = await supabase.functions.invoke("create-voice-room", { body: { name } });
      if (error || !data?.url) {
        showNotif("❌ Could not create voice room", "error"); return;
      }

      await supabase.from("voice_rooms").upsert(
        { name, daily_room_url: data.url, is_active: true, created_by: user.id },
        { onConflict: "created_by" }
      );

      const call = createDailyCall();
      await call.join({ url: data.url, startVideoOff: true, startAudioOff: false });

      setVoiceRoom(data.url, name);
      showNotif("🎙 Connected!", "success");
    } catch (err: any) {
      showNotif(`❌ ${err?.message ?? "Voice failed"}`, "error");
    }
  }, [voiceActive, setVoiceRoom, showNotif]);

  const leave = useCallback(async () => {
    await leaveInternal();
  }, [leaveVoiceRoom, showNotif]);

  const joinByUrl = useCallback(async (url: string, name: string) => {
    try {
      showNotif("🎙 Joining…", "success");
      const call = createDailyCall();
      await call.join({ url, startVideoOff: true, startAudioOff: false });
      setVoiceRoom(url, name);
      showNotif("🎙 Joined!", "success");
    } catch (err: any) {
      showNotif(`❌ ${err?.message ?? "Could not join"}`, "error");
    }
  }, [setVoiceRoom, showNotif]);

  return { voiceActive, voiceRoomName, voiceParticipants, join, leave, joinByUrl };
}
