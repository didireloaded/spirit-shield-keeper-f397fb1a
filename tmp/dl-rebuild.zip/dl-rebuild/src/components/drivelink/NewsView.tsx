import { useState } from "react";
import { useRoadNews, type NewsArticle } from "@/hooks/useRoadNews";

const LIME   = "hsl(75 100% 47%)";
const GREEN  = "hsl(145 63% 47%)";
const RED    = "hsl(0 90% 58%)";
const ORANGE = "hsl(30 100% 54%)";
const PURPLE = "hsl(270 60% 65%)";
const BLUE   = "hsl(202 90% 62%)";

const FILTERS: { key: NewsArticle["category"] | "all"; label: string }[] = [
  { key: "all",      label: "All"      },
  { key: "accident", label: "Accident" },
  { key: "traffic",  label: "Traffic"  },
  { key: "road",     label: "Roads"    },
  { key: "weather",  label: "Weather"  },
  { key: "general",  label: "General"  },
];

const CAT_COLOR: Record<string, string> = {
  accident: RED, traffic: ORANGE, road: LIME, weather: BLUE, general: GREEN,
};

function timeAgo(dateStr: string) {
  const m = Math.round((Date.now() - new Date(dateStr).getTime()) / 60000);
  if (m < 1)    return "now";
  if (m < 60)   return `${m}m`;
  if (m < 1440) return `${Math.floor(m / 60)}h`;
  return `${Math.floor(m / 1440)}d`;
}

export function NewsView() {
  const { articles, loading, error, refresh, lastFetch } = useRoadNews();
  const [activeFilter, setActiveFilter] = useState<NewsArticle["category"] | "all">("all");

  const filtered = activeFilter === "all" ? articles : articles.filter((a) => a.category === activeFilter);
  const counts: Record<string, number> = {};
  articles.forEach((a) => { counts[a.category] = (counts[a.category] || 0) + 1; });

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div
        className="flex-shrink-0 px-4 md:px-5 pt-5 pb-3 border-b"
        style={{ borderColor: "hsl(60 5% 14%)" }}
      >
        <div className="flex items-end justify-between max-w-5xl">
          <div>
            <h2 className="font-display text-xl tracking-wider text-foreground leading-none">Namibia News</h2>
            <p className="font-body text-[0.6rem] text-muted-foreground mt-1">
              {articles.length} articles
              {lastFetch > 0 && (
                <span className="ml-2 opacity-40 font-data">
                  · updated {timeAgo(new Date(lastFetch).toISOString())} ago
                </span>
              )}
            </p>
          </div>
          <div className="flex items-center gap-2.5">
            <span
              className="flex items-center gap-1.5 font-display text-[0.56rem] tracking-[0.16em] uppercase"
              style={{ color: GREEN }}
            >
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: GREEN, display: "inline-block", animation: "pulse-dot 2s infinite" }} />
              Live
            </span>
            <button
              onClick={refresh}
              disabled={loading}
              className="w-7 h-7 rounded border flex items-center justify-center text-sm text-muted-foreground cursor-pointer transition-all disabled:opacity-40 border-none"
              style={{ background: "hsl(60 6% 11%)", border: "1px solid hsl(60 5% 16%)", animation: loading ? "spin 1s linear infinite" : "none" }}
            >
              ↻
            </button>
          </div>
        </div>

        {/* Filter pills */}
        <div className="flex gap-1.5 mt-3 overflow-x-auto hide-scrollbar pb-0.5 max-w-5xl">
          {FILTERS.map((f) => {
            const isActive = activeFilter === f.key;
            const count    = f.key === "all" ? articles.length : (counts[f.key] || 0);
            const color    = f.key === "all" ? LIME : (CAT_COLOR[f.key] ?? GREEN);
            return (
              <button
                key={f.key}
                onClick={() => setActiveFilter(f.key)}
                className="flex-shrink-0 px-3 py-1 rounded font-display text-[0.54rem] tracking-[0.12em] uppercase border cursor-pointer transition-all"
                style={isActive
                  ? { background: `${color}15`, borderColor: `${color}40`, color }
                  : { background: "hsl(60 6% 9%)", borderColor: "hsl(60 5% 16%)", color: "hsl(60 4% 42%)" }
                }
              >
                {f.label}
                {count > 0 && <span className="ml-1.5 opacity-50 font-data">{count}</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Articles */}
      <div className="flex-1 overflow-y-auto px-4 md:px-5 pt-3 pb-4 hide-scrollbar">
        {/* Skeleton */}
        {loading && articles.length === 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 max-w-5xl">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="rounded border p-4 space-y-2.5 animate-pulse"
                   style={{ background: "hsl(60 6% 9%)", borderColor: "hsl(60 5% 14%)" }}>
                <div className="h-2.5 w-14 rounded-full" style={{ background: "hsl(60 5% 15%)" }} />
                <div className="h-4 rounded" style={{ background: "hsl(60 5% 15%)" }} />
                <div className="h-3 w-3/4 rounded" style={{ background: "hsl(60 5% 13%)" }} />
              </div>
            ))}
          </div>
        )}

        {!loading && error && articles.length === 0 && (
          <div className="flex flex-col items-center justify-center h-40 text-center">
            <p className="text-3xl mb-3">📡</p>
            <p className="font-body text-sm text-muted-foreground">{error}</p>
            <button onClick={refresh} className="mt-3 font-display text-xs tracking-wider cursor-pointer bg-transparent border-none underline" style={{ color: LIME }}>
              RETRY
            </button>
          </div>
        )}

        {error && articles.length > 0 && (
          <div className="rounded border px-3 py-2 mb-3 font-body text-[0.62rem] max-w-5xl"
               style={{ background: `${ORANGE}0a`, borderColor: `${ORANGE}25`, color: ORANGE }}>
            ⚠ Showing cached news · {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 max-w-5xl">
          {filtered.map((article) => {
            const color = CAT_COLOR[article.category] ?? GREEN;
            return (
              <a
                key={article.id}
                href={article.url}
                target="_blank"
                rel="noopener noreferrer"
                className="block rounded no-underline transition-all active:scale-[0.99] group"
                style={{
                  background:  "hsl(60 6% 9%)",
                  border:      `1px solid hsl(60 5% 14%)`,
                  borderLeft:  `3px solid ${color}`,
                  padding:     "12px 14px",
                }}
              >
                {/* Top row */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span
                    className="font-display text-[0.5rem] tracking-[0.14em] uppercase"
                    style={{ color }}
                  >
                    {article.category}
                  </span>
                  <span className="font-data text-[0.5rem] text-muted-foreground">{timeAgo(article.published)}</span>
                </div>

                {/* Title */}
                <p className="font-body text-[0.82rem] text-foreground leading-snug font-medium mb-1.5 group-hover:opacity-90">
                  {article.title}
                </p>

                {article.description && (
                  <p className="font-body text-[0.68rem] text-muted-foreground leading-snug line-clamp-2 mb-2">
                    {article.description}
                  </p>
                )}

                <div className="flex justify-between items-center font-body text-[0.56rem]">
                  <span className="text-muted-foreground/50">{article.source}</span>
                  <span style={{ color: `${color}99` }}>Read →</span>
                </div>
              </a>
            );
          })}
        </div>

        {!loading && filtered.length === 0 && articles.length > 0 && (
          <p className="font-body text-xs text-muted-foreground text-center py-8">No articles in this category</p>
        )}
        {!loading && articles.length > 0 && (
          <p className="font-data text-[0.5rem] text-muted-foreground text-center py-2 opacity-40 tracking-wider">
            AUTO-REFRESH 15MIN
          </p>
        )}
      </div>
    </div>
  );
}
