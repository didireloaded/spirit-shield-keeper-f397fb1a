import { useState } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useStore } from "@/store";
import { useVoiceRoom } from "@/hooks/useVoiceRoom";

const BLUE = "hsl(202 90% 62%)";
const RED  = "hsl(0 90% 58%)";

export function PersistentVoiceBar() {
  const room      = useStore((s) => s.activeVoiceRoom);
  const { leave } = useVoiceRoom();
  const [expanded, setExpanded] = useState(false);

  if (!room) return null;

  return (
    <>
      <AnimatePresence>
        {!expanded && (
          <motion.div
            key="voice-bar"
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="flex-shrink-0 flex items-center justify-between px-4 py-2.5 border-b z-30 cursor-pointer"
            style={{ background: `${BLUE}0c`, borderColor: `${BLUE}25` }}
          >
            <button
              onClick={() => setExpanded(true)}
              className="flex items-center gap-2.5 bg-transparent border-none flex-1 text-left cursor-pointer"
            >
              <div className="relative flex-shrink-0 w-5 h-5 flex items-center justify-center">
                <span className="text-sm relative z-10">🎙</span>
                <span
                  className="absolute inset-0 rounded-full border"
                  style={{ borderColor: `${BLUE}60`, animation: "ring-expand 1.8s infinite" }}
                />
              </div>
              <div>
                <p className="font-display text-[0.72rem] tracking-wider leading-none" style={{ color: BLUE }}>
                  {room.name}
                </p>
                <p className="font-data text-[0.5rem] mt-0.5 opacity-60" style={{ color: BLUE }}>
                  ● LIVE · tap to open
                </p>
              </div>
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); leave(); }}
              className="font-display text-[0.56rem] tracking-[0.14em] rounded px-3 py-1.5 cursor-pointer border transition-all ml-3 flex-shrink-0"
              style={{ background: `${RED}12`, borderColor: `${RED}35`, color: RED }}
            >
              END
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {createPortal(
        <div
          className="fixed inset-0 z-[9999] flex flex-col transition-opacity duration-200"
          style={{
            background:    "hsl(60 8% 5%)",
            opacity:       expanded ? 1 : 0,
            pointerEvents: expanded ? "auto" : "none",
            visibility:    expanded ? "visible" : "hidden",
          }}
        >
          {/* Top bar */}
          <div
            className="flex-shrink-0 flex items-center justify-between px-5 py-4 border-b"
            style={{ borderColor: "hsl(60 5% 14%)" }}
          >
            <div>
              <p className="font-display text-lg tracking-wider leading-none" style={{ color: BLUE }}>
                🎙 {room.name}
              </p>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: BLUE, animation: "pulse-dot 2s infinite", display: "inline-block" }} />
                <span className="font-data text-[0.54rem] tracking-widest uppercase" style={{ color: BLUE }}>Live</span>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setExpanded(false)}
                className="font-display text-[0.6rem] tracking-wider rounded px-3 py-1.5 cursor-pointer border"
                style={{ background: "hsl(60 6% 11%)", borderColor: "hsl(60 5% 18%)", color: "hsl(60 4% 50%)" }}
              >
                MINIMISE
              </button>
              <button
                onClick={() => { setExpanded(false); leave(); }}
                className="font-display text-[0.6rem] tracking-wider rounded px-3 py-1.5 cursor-pointer border"
                style={{ background: `${RED}12`, borderColor: `${RED}35`, color: RED }}
              >
                LEAVE
              </button>
            </div>
          </div>

          {/* Iframe */}
          <div className="flex-1 relative">
            {room.url ? (
              <iframe
                src={`${room.url}?embed=1&showLeaveButton=0&showFullscreenButton=0`}
                className="absolute inset-0 w-full h-full border-none"
                allow="camera; microphone; fullscreen; display-capture"
                title="Voice Room"
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-5xl mb-4 animate-pulse">🎙</div>
                  <p className="font-data text-sm text-muted-foreground">CONNECTING…</p>
                </div>
              </div>
            )}
          </div>
        </div>,
        document.body
      )}
    </>
  );
}
