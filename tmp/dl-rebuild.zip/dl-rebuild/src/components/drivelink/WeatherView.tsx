import { useWeather } from "@/hooks/useWeather";
import { useStore } from "@/store";

const LIME   = "hsl(75 100% 47%)";
const GREEN  = "hsl(145 63% 47%)";
const ORANGE = "hsl(30 100% 54%)";
const RED    = "hsl(0 90% 58%)";

const RISK_MAP = {
  low:      { color: GREEN,  label: "GOOD CONDITIONS"     },
  moderate: { color: ORANGE, label: "DRIVE WITH CAUTION"  },
  high:     { color: RED,    label: "HIGH RISK — SLOW DOWN" },
};

export function WeatherView() {
  const { weather, loading } = useWeather();
  const city = useStore((s) => s.currentCity);

  if (loading) return (
    <div className="flex flex-col h-full">
      <div className="px-4 md:px-5 pt-5 pb-3 border-b flex-shrink-0" style={{ borderColor: "hsl(60 5% 14%)" }}>
        <h2 className="font-display text-xl tracking-wider text-foreground">Weather</h2>
      </div>
      <div className="flex-1 flex items-center justify-center">
        <div className="w-7 h-7 border-2 border-t-transparent rounded-full animate-spin"
             style={{ borderColor: `${LIME} transparent transparent transparent` }} />
      </div>
    </div>
  );

  if (!weather) return (
    <div className="flex flex-col h-full items-center justify-center">
      <p className="text-3xl mb-2">📡</p>
      <p className="font-body text-sm text-muted-foreground">Weather unavailable</p>
    </div>
  );

  const { color: riskColor, label: riskLabel } = RISK_MAP[weather.drivingRisk];

  const conditionColor = (risk: string) =>
    risk === "high" ? RED : risk === "moderate" ? ORANGE : GREEN;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex-shrink-0 px-4 md:px-5 pt-5 pb-3 border-b" style={{ borderColor: "hsl(60 5% 14%)" }}>
        <h2 className="font-display text-xl tracking-wider text-foreground leading-none">Weather</h2>
        <p className="font-body text-[0.62rem] text-muted-foreground mt-1">{city ?? "Namibia"} · live conditions</p>
      </div>

      <div className="flex-1 overflow-y-auto px-4 md:px-5 pt-3 pb-4 hide-scrollbar">
        <div className="flex flex-col md:flex-row gap-3 max-w-4xl">

          {/* Big temp card */}
          <div
            className="md:flex-1 rounded border relative overflow-hidden"
            style={{ background: "hsl(60 6% 9%)", borderColor: "hsl(60 5% 14%)", borderLeft: `3px solid ${LIME}` }}
          >
            {/* Subtle radial highlight */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{ background: `radial-gradient(circle at 20% 80%, ${LIME}06 0%, transparent 60%)` }}
            />
            <div className="relative z-10 p-5 text-center">
              <div className="text-5xl mb-2">{weather.icon}</div>
              <div className="font-data text-6xl font-bold text-foreground leading-none">
                {weather.temp}°
              </div>
              <div className="font-display text-[0.7rem] tracking-[0.12em] text-muted-foreground mt-1.5 uppercase">
                {weather.description}
              </div>
              <div className="font-body text-[0.65rem] mt-1" style={{ color: LIME }}>
                Feels {weather.feelsLike}°C
              </div>

              {/* 4 metrics */}
              <div className="grid grid-cols-4 gap-2 mt-5">
                {[
                  { val: `${weather.humidity}%`,      label: "Humid"   },
                  { val: `${weather.windSpeed}km/h`,  label: `Wind ${weather.windDir}` },
                  { val: `${weather.visibility}km`,   label: "Vis"     },
                  { val: `UV${weather.uvIndex}`,       label: "UV"      },
                ].map((m, i) => (
                  <div key={i} className="rounded py-2 border" style={{ background: "hsl(60 6% 7%)", borderColor: "hsl(60 5% 13%)" }}>
                    <div className="font-data text-xs font-bold text-foreground leading-none">{m.val}</div>
                    <div className="font-display text-[0.44rem] tracking-[0.12em] text-muted-foreground mt-0.5 uppercase">{m.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right column */}
          <div className="md:w-72 flex flex-col gap-3">
            {/* Risk banner */}
            <div
              className="rounded border px-4 py-3"
              style={{ background: `${riskColor}0c`, borderColor: `${riskColor}30`, borderLeft: `3px solid ${riskColor}` }}
            >
              <div className="font-display text-[0.78rem] tracking-[0.14em] uppercase mb-2" style={{ color: riskColor }}>
                {riskLabel}
              </div>
              {weather.riskReasons.map((r, i) => (
                <p key={i} className="font-body text-[0.66rem] leading-relaxed mt-1" style={{ color: riskColor }}>
                  · {r}
                </p>
              ))}
            </div>

            {/* Road conditions */}
            <div className="scard">
              <div className="section-label">Road Conditions</div>
              {[
                {
                  label: "Surface",
                  val: weather.drivingRisk === "high" ? "Slippery ⚠" : weather.drivingRisk === "moderate" ? "Damp" : "Dry ✓",
                  color: conditionColor(weather.drivingRisk),
                },
                {
                  label: "Visibility",
                  val: weather.visibility < 1 ? "Poor ⚠" : weather.visibility < 5 ? "Reduced" : "Clear ✓",
                  color: weather.visibility < 1 ? RED : weather.visibility < 5 ? ORANGE : GREEN,
                },
                {
                  label: "Wind",
                  val: weather.windSpeed > 60 ? "Strong ⚠" : weather.windSpeed > 30 ? "Moderate" : "Light ✓",
                  color: weather.windSpeed > 60 ? RED : weather.windSpeed > 30 ? ORANGE : GREEN,
                },
              ].map((row, i) => (
                <div
                  key={i}
                  className="flex justify-between items-center py-2 border-b last:border-0"
                  style={{ borderColor: "hsl(60 5% 14%)" }}
                >
                  <span className="font-body text-[0.68rem] text-muted-foreground">{row.label}</span>
                  <span className="font-body text-[0.68rem] font-medium" style={{ color: row.color }}>{row.val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Hourly */}
        <div className="scard mt-3 max-w-4xl">
          <div className="section-label">Next 6 Hours</div>
          <div className="flex gap-4 overflow-x-auto pb-1 hide-scrollbar">
            {weather.hourly.map((h, i) => (
              <div key={i} className="text-center flex-shrink-0 min-w-[50px]">
                <div className="font-data text-[0.56rem] text-muted-foreground">{h.time}</div>
                <div className="text-xl my-1.5">{h.icon}</div>
                <div className="font-data text-sm font-bold text-foreground">{h.temp}°</div>
                {h.rain > 0 && (
                  <div className="font-data text-[0.5rem] mt-0.5" style={{ color: LIME }}>{h.rain}%</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
