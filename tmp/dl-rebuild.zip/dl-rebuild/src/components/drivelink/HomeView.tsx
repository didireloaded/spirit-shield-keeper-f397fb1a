import { useStore } from "@/store";
import { useReports, type Report } from "@/hooks/useReports";
import { useProfile } from "@/hooks/useProfile";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useDriversOnMap } from "@/hooks/usePresence";
import { useVoiceRoom } from "@/hooks/useVoiceRoom";
import { DriveMap } from "./DriveMap";
import { LocationTag } from "@/components/ui/location-tag";
import { motion } from "framer-motion";
import { useCallback } from "react";

const POINTS: Record<string, number> = {
  police: 2, accident: 2, hazard: 2, traffic: 2, pothole: 3,
};

const REPORT_BTNS = [
  { type: "police"   as const, icon: "🚔", label: "Police",   color: "hsl(0 90% 58%)"  },
  { type: "accident" as const, icon: "🚗", label: "Accident", color: "hsl(30 100% 54%)" },
  { type: "hazard"   as const, icon: "⚠️",  label: "Hazard",   color: "hsl(45 100% 52%)" },
  { type: "traffic"  as const, icon: "🚦", label: "Traffic",  color: "hsl(202 90% 62%)" },
  { type: "pothole"  as const, icon: "🕳️",  label: "Pothole",  color: "hsl(270 60% 65%)" },
];

const ICONS: Record<string, string> = {
  police: "🚔", accident: "🚗", hazard: "⚠️", traffic: "🚦", pothole: "🕳️",
};

const LIME   = "hsl(75 100% 47%)";
const GREEN  = "hsl(145 63% 47%)";
const ORANGE = "hsl(30 100% 54%)";
const RED    = "hsl(0 90% 58%)";

export function HomeView() {
  const score         = useStore((s) => s.score);
  const speed         = useStore((s) => s.currentSpeed);
  const speedLimit    = useStore((s) => s.speedLimit);
  const reportsToday  = useStore((s) => s.reportsToday);
  const nearbyDrivers = useStore((s) => s.nearbyDrivers);
  const rank          = useStore((s) => s.rank);
  const weeklyReports = useStore((s) => s.weeklyReports);
  const showNotif     = useStore((s) => s.showNotification);
  const currentCity   = useStore((s) => s.currentCity);
  const ghostMode     = useStore((s) => s.ghostMode);
  const toggleGhost   = useStore((s) => s.toggleGhostMode);

  const { reports, loading, submitReport, confirmReport } = useReports();
  const { syncScore }  = useProfile();
  const geo            = useGeolocation();
  const driversOnMap   = useDriversOnMap();
  const { voiceActive, voiceParticipants, join: joinVoice } = useVoiceRoom();

  const speedStatus = speed > 120 ? "danger" : speed > speedLimit ? "warn" : "safe";
  const speedClass  = speedStatus === "danger" ? "speed-danger" : speedStatus === "warn" ? "speed-warn" : "speed-safe";
  const progress    = Math.min((reportsToday / 10) * 100, 100);
  const speedColor  = speedStatus === "danger" ? RED : speedStatus === "warn" ? ORANGE : GREEN;

  const handleReport = useCallback(async (type: Report["type"]) => {
    const ok = await submitReport(type, geo.lat ?? undefined, geo.lng ?? undefined);
    if (ok) {
      const pts = POINTS[type] ?? 2;
      await syncScore(pts, type);
      showNotif(`${ICONS[type]} +${pts} pts`, "success");
    }
  }, [submitReport, syncScore, showNotif, geo.lat, geo.lng]);

  const recentReports = reports.slice(0, 5);

  return (
    <div className="flex flex-col h-full">

      {/* ── HUD bar ─────────────────────────────────────── */}
      <div
        className="flex-shrink-0 border-b"
        style={{ background: "hsl(60 7% 7%)", borderColor: "hsl(60 5% 14%)" }}
      >
        {/* Mobile wordmark */}
        <div className="md:hidden flex items-center justify-between px-4 pt-4 pb-2">
          <div className="flex items-baseline gap-1.5">
            <span className="font-display text-xl font-bold tracking-wider" style={{ color: LIME }}>DRIVE</span>
            <span className="font-display text-xl font-bold tracking-wider text-foreground/40">LINK</span>
          </div>
          <span className="font-data text-[0.5rem] text-muted-foreground uppercase tracking-widest">Namibia</span>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 divide-x divide-border max-w-xl mx-0 md:ml-0">
          {/* Score */}
          <div className="flex flex-col items-center justify-center py-3 px-2">
            <span className="font-data text-2xl font-bold leading-none" style={{ color: LIME }}>{score}</span>
            <span className="font-display text-[0.5rem] tracking-[0.2em] text-muted-foreground mt-1 uppercase">Score</span>
          </div>

          {/* Speed — hero */}
          <div className="flex flex-col items-center justify-center py-2 px-2">
            <div className={`flex flex-col items-center justify-center px-5 py-1.5 rounded ${speed > 0 ? speedClass : ""}`}>
              <span
                className="font-data text-2xl font-bold leading-none"
                style={{ color: speed > 0 ? "white" : "hsl(60 4% 38%)" }}
              >
                {speed > 0 ? speed : "—"}
              </span>
              <span
                className="font-display text-[0.46rem] tracking-[0.2em] mt-0.5 uppercase"
                style={{ color: speed > 0 ? "rgba(255,255,255,0.65)" : "hsl(60 4% 38%)" }}
              >
                km/h
              </span>
            </div>
          </div>

          {/* Limit */}
          <div className="flex flex-col items-center justify-center py-3 px-2">
            <span className="font-data text-2xl font-bold leading-none text-foreground/50">{speedLimit}</span>
            <span className="font-display text-[0.5rem] tracking-[0.2em] text-muted-foreground mt-1 uppercase">Limit</span>
          </div>
        </div>
      </div>

      {/* ── Scrollable body ─────────────────────────────── */}
      <div className="flex-1 overflow-y-auto px-3 md:px-5 pt-3 pb-4 hide-scrollbar space-y-3">

        {/* Map + Voice row */}
        <div className="flex flex-col lg:flex-row gap-3">
          {/* Map */}
          <div
            className="lg:flex-1 h-52 md:h-64 lg:h-72 rounded relative overflow-hidden border"
            style={{ borderColor: "hsl(60 5% 16%)" }}
          >
            <DriveMap
              lat={geo.lat} lng={geo.lng} accuracy={geo.accuracy}
              reports={reports} drivers={driversOnMap} ghostMode={ghostMode}
            />

            {geo.loading && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm z-10">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-5 h-5 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: `${LIME} transparent transparent transparent` }} />
                  <span className="font-data text-xs text-white/50">ACQUIRING GPS</span>
                </div>
              </div>
            )}
            {geo.error && !geo.loading && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm z-10">
                <p className="font-data text-[0.65rem] text-white/40 text-center px-6">⚠ {geo.error}</p>
              </div>
            )}

            <div className="absolute top-2 left-2 z-10 scale-[0.85] origin-top-left">
              <LocationTag city={currentCity ?? "Windhoek"} country="NA" timezone="CAT" />
            </div>

            <button
              onClick={toggleGhost}
              className="absolute top-2 right-2 z-10 px-2 py-1 rounded border font-display text-[0.56rem] tracking-wider uppercase transition-all"
              style={ghostMode
                ? { background: "hsl(270 60% 65% / 0.2)", borderColor: "hsl(270 60% 65% / 0.4)", color: "hsl(270 60% 65%)" }
                : { background: "rgba(0,0,0,0.7)", borderColor: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }
              }
            >
              {ghostMode ? "Ghost" : "Visible"}
            </button>

            {geo.accuracy && (
              <div
                className="absolute bottom-2 left-2 z-10 px-2 py-0.5 rounded border font-data text-[0.52rem]"
                style={{ background: "rgba(0,0,0,0.65)", borderColor: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.4)" }}
              >
                ±{Math.round(geo.accuracy)}m
              </div>
            )}
          </div>

          {/* Voice button */}
          <div className="flex lg:flex-col items-center justify-center gap-4 lg:gap-2 lg:w-28 py-2">
            <div className="text-center">
              <p className="font-display text-[0.52rem] tracking-[0.18em] uppercase text-muted-foreground mb-2">Voice</p>
              <div className="relative inline-flex">
                <button
                  onClick={() => joinVoice()}
                  className="w-16 h-16 rounded-full border-2 flex items-center justify-center text-xl transition-all hover:scale-105"
                  style={{
                    background:    voiceActive ? "hsl(202 90% 62% / 0.15)" : "hsl(60 6% 11%)",
                    borderColor:   voiceActive ? "hsl(202 90% 62%)" : "hsl(60 5% 20%)",
                    animation:     voiceActive ? "voice-pulse 1.5s infinite" : "none",
                  }}
                >
                  🎙
                </button>
                {voiceActive && (
                  <span
                    className="absolute -inset-2 rounded-full border"
                    style={{ borderColor: "hsl(202 90% 62% / 0.3)", animation: "ring-expand 2s infinite" }}
                  />
                )}
              </div>
              <p className="font-data text-[0.52rem] mt-1.5" style={{ color: voiceActive ? "hsl(202 90% 62%)" : "hsl(60 4% 38%)" }}>
                {voiceActive ? `● ${voiceParticipants} live` : "tap to join"}
              </p>
            </div>
          </div>
        </div>

        {/* Reports + Stats */}
        <div className="flex flex-col md:flex-row gap-3">
          {/* Quick Report */}
          <div className="tcard md:flex-1">
            <div className="section-label">
              Quick Report
              <span className="font-body text-[0.58rem] font-normal normal-case tracking-normal"
                    style={{ color: GREEN, display: "flex", alignItems: "center", gap: "5px" }}>
                <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ background: GREEN, animation: "pulse-dot 2s infinite" }} />
                tap to report
              </span>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {REPORT_BTNS.map((btn) => (
                <button
                  key={btn.type}
                  onClick={() => handleReport(btn.type)}
                  className="aspect-square rounded flex flex-col items-center justify-center gap-0.5 border transition-all active:scale-90 cursor-pointer"
                  style={{
                    background:  `${btn.color}12`,
                    borderColor: `${btn.color}30`,
                  }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.background = `${btn.color}22`; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.background = `${btn.color}12`; }}
                >
                  <span className="text-lg leading-none">{btn.icon}</span>
                  <span className="font-display text-[0.42rem] tracking-[0.1em] uppercase leading-none" style={{ color: btn.color }}>
                    {btn.label}
                  </span>
                </button>
              ))}
            </div>
            <div
              className="mt-2.5 px-3 py-1.5 rounded text-[0.6rem] font-body"
              style={{ background: `${LIME}0a`, border: `1px solid ${LIME}20`, color: `${LIME}cc` }}
            >
              💡 Accurate reports earn bonus points for all drivers
            </div>
          </div>

          {/* Stats */}
          <div className="scard md:flex-1">
            <div className="section-label">
              Driver Stats
              <span className="font-body text-[0.58rem] font-normal normal-case tracking-normal"
                    style={{ color: GREEN, display: "flex", alignItems: "center", gap: "5px" }}>
                <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ background: GREEN, animation: "pulse-dot 2s infinite" }} />
                live
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 mb-3">
              {[
                { val: reportsToday,         label: "Today",   clr: GREEN  },
                { val: nearbyDrivers || "—", label: "Nearby",  clr: LIME   },
                { val: weeklyReports,        label: "Weekly",  clr: ORANGE },
                { val: rank,                 label: "Rank",    clr: "hsl(270 60% 65%)" },
              ].map((s, i) => (
                <div
                  key={i}
                  className="rounded py-2.5 px-3 text-center border"
                  style={{ background: "hsl(60 6% 8%)", borderColor: "hsl(60 5% 15%)" }}
                >
                  <div className="font-data text-xl font-bold leading-none" style={{ color: s.clr }}>{s.val}</div>
                  <div className="font-display text-[0.48rem] tracking-[0.16em] text-muted-foreground uppercase mt-1">{s.label}</div>
                </div>
              ))}
            </div>
            {/* Daily goal */}
            <div>
              <div className="flex justify-between font-display text-[0.56rem] tracking-wider uppercase mb-1.5">
                <span className="text-muted-foreground">Daily Goal</span>
                <span style={{ color: LIME, fontFamily: "JetBrains Mono" }}>{reportsToday}/10</span>
              </div>
              <div className="h-1 rounded-full" style={{ background: `${LIME}18` }}>
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: LIME }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.6, ease: "easeOut" }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Live Activity */}
        <div className="scard">
          <div className="section-label">
            Live Activity
            <span className="font-body text-[0.58rem] font-normal normal-case tracking-normal"
                  style={{ color: GREEN, display: "flex", alignItems: "center", gap: "5px" }}>
              <span className="w-1.5 h-1.5 rounded-full inline-block" style={{ background: GREEN, animation: "pulse-dot 2s infinite" }} />
              live
            </span>
          </div>
          {loading ? (
            <p className="font-data text-[0.65rem] text-muted-foreground py-4 text-center">LOADING…</p>
          ) : recentReports.length === 0 ? (
            <p className="font-body text-xs text-muted-foreground py-4 text-center">No reports yet. Be the first!</p>
          ) : (
            <div className="space-y-1.5">
              {recentReports.map((r, idx) => (
                <motion.div
                  key={r.id}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.04 }}
                  className="flex items-center gap-3 px-3 py-2.5 rounded border"
                  style={{ background: "hsl(60 6% 8%)", borderColor: "hsl(60 5% 14%)" }}
                >
                  <span className="text-sm flex-shrink-0">{ICONS[r.type] ?? "📍"}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-body text-[0.72rem] text-foreground leading-none capitalize">{r.type} reported</p>
                    <div className="flex gap-3 mt-1 font-data text-[0.56rem] text-muted-foreground">
                      <span>{new Date(r.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
                      <span style={{ color: GREEN }}>{r.confirmed_by} confirms</span>
                    </div>
                  </div>
                  <button
                    onClick={() => confirmReport(r.id)}
                    className="flex-shrink-0 rounded px-2.5 py-1 font-display text-[0.58rem] tracking-wider border cursor-pointer transition-all"
                    style={{
                      background:  `${GREEN}12`,
                      borderColor: `${GREEN}30`,
                      color:       GREEN,
                    }}
                    onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.background = `${GREEN}22`; }}
                    onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.background = `${GREEN}12`; }}
                  >
                    ✓ Confirm
                  </button>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
