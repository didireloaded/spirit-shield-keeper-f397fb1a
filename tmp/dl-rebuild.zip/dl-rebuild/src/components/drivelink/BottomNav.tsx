import { useStore, type ViewType } from "@/store";
import { motion } from "framer-motion";

const tabs: { id: ViewType; icon: string; label: string }[] = [
  { id: "home",    icon: "◉", label: "Drive"   },
  { id: "dm",      icon: "◈", label: "Chat"    },
  { id: "news",    icon: "▦", label: "News"    },
  { id: "weather", icon: "◌", label: "Sky"     },
  { id: "help",    icon: "⚡", label: "Help"    },
];

const LIME    = "hsl(75 100% 47%)";
const DIM     = "hsl(60 4% 38%)";
const BG_ACT  = "hsl(75 100% 47% / 0.07)";

export function BottomNav() {
  const activeView  = useStore((s) => s.currentView);
  const setView     = useStore((s) => s.setView);
  const hasDmNotif  = useStore((s) => s.hasDmNotif);
  const voiceActive = useStore((s) => s.voiceActive);

  return (
    <div
      className="flex-shrink-0 z-50 border-t"
      style={{
        background:    "hsl(60 8% 5%)",
        borderColor:   "hsl(60 5% 14%)",
        paddingBottom: "env(safe-area-inset-bottom, 8px)",
      }}
    >
      <div className="flex justify-around items-stretch px-1 pt-1.5 pb-1">
        {tabs.map((tab) => {
          const isActive = activeView === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setView(tab.id)}
              className="relative flex flex-col items-center gap-0.5 px-3 py-1.5 rounded min-w-[52px] border-none cursor-pointer transition-colors"
              style={{ background: isActive ? BG_ACT : "transparent" }}
            >
              {/* Lime top bar for active */}
              {isActive && (
                <motion.div
                  layoutId="nav-bar"
                  className="absolute top-0 left-2 right-2 h-[2px] rounded-b"
                  style={{ background: LIME }}
                  transition={{ type: "spring", stiffness: 500, damping: 40 }}
                />
              )}

              <span
                className="text-base leading-none"
                style={{ color: isActive ? LIME : DIM }}
              >
                {tab.icon}
              </span>
              <span
                className="font-display text-[0.46rem] tracking-[0.16em] uppercase"
                style={{ color: isActive ? LIME : DIM }}
              >
                {tab.label}
              </span>

              {/* DM unread dot */}
              {tab.id === "dm" && hasDmNotif && !voiceActive && (
                <motion.span
                  initial={{ scale: 0 }} animate={{ scale: 1 }}
                  className="absolute top-1 right-1.5 w-1.5 h-1.5 rounded-full"
                  style={{ background: "hsl(0 90% 58%)", animation: "pulse-dot 2s infinite" }}
                />
              )}

              {/* Voice live dot */}
              {tab.id === "dm" && voiceActive && (
                <span
                  className="absolute top-1 right-1.5 w-2 h-2 rounded-full border-2"
                  style={{
                    background: "hsl(202 90% 62%)",
                    borderColor: "hsl(60 8% 5%)",
                    animation: "pulse-dot 1.2s infinite",
                  }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
