import { useStore, type ViewType } from "@/store";
import { motion } from "framer-motion";

const tabs: { id: ViewType; icon: string; label: string }[] = [
  { id: "home",    icon: "◉", label: "Drive"   },
  { id: "dm",      icon: "◈", label: "Chat"    },
  { id: "news",    icon: "▦", label: "News"    },
  { id: "weather", icon: "◌", label: "Sky"     },
  { id: "help",    icon: "⚡", label: "Help"    },
];

const LIME = "hsl(75 100% 47%)";

export function DesktopSidebar() {
  const activeView  = useStore((s) => s.currentView);
  const setView     = useStore((s) => s.setView);
  const hasDmNotif  = useStore((s) => s.hasDmNotif);
  const voiceActive = useStore((s) => s.voiceActive);
  const score       = useStore((s) => s.score);
  const rank        = useStore((s) => s.rank);

  return (
    <aside
      className="hidden md:flex flex-col w-[200px] flex-shrink-0 h-[100dvh] border-r"
      style={{ background: "hsl(60 8% 5%)", borderColor: "hsl(60 5% 14%)" }}
    >
      {/* Wordmark */}
      <div className="px-5 pt-7 pb-5 border-b" style={{ borderColor: "hsl(60 5% 14%)" }}>
        <div className="flex items-baseline gap-2">
          <span className="font-display text-2xl font-bold tracking-[0.08em]" style={{ color: LIME }}>
            DRIVE
          </span>
          <span className="font-display text-2xl font-bold tracking-[0.08em] text-foreground/50">
            LINK
          </span>
        </div>
        <p className="font-data text-[0.52rem] text-muted-foreground mt-1 tracking-widest uppercase">
          Namibia Safety Net
        </p>
      </div>

      {/* Nav */}
      <nav className="flex-1 flex flex-col py-3 px-2">
        {tabs.map((tab) => {
          const isActive = activeView === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setView(tab.id)}
              className="relative flex items-center gap-3 px-3 py-2.5 rounded transition-all duration-150 border-none w-full text-left cursor-pointer mb-0.5"
              style={{
                background:   isActive ? "hsl(75 100% 47% / 0.08)" : "transparent",
                borderLeft:   isActive ? `2px solid ${LIME}` : "2px solid transparent",
                color:        isActive ? LIME : "hsl(60 4% 42%)",
              }}
            >
              <span className="text-base leading-none flex-shrink-0">{tab.icon}</span>
              <span className="font-display text-sm font-semibold tracking-[0.1em] uppercase">
                {tab.label}
              </span>

              {tab.id === "dm" && hasDmNotif && !voiceActive && (
                <motion.span
                  initial={{ scale: 0 }} animate={{ scale: 1 }}
                  className="w-1.5 h-1.5 rounded-full ml-auto"
                  style={{ background: "hsl(0 90% 58%)", animation: "pulse-dot 2s infinite" }}
                />
              )}
              {tab.id === "dm" && voiceActive && (
                <span
                  className="w-2 h-2 rounded-full border-2 ml-auto"
                  style={{ background: "hsl(202 90% 62%)", borderColor: "hsl(60 8% 5%)", animation: "pulse-dot 1.2s infinite" }}
                />
              )}
            </button>
          );
        })}
      </nav>

      {/* Score strip */}
      <div className="px-4 pb-6 pt-4 border-t" style={{ borderColor: "hsl(60 5% 14%)" }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded flex items-center justify-center text-sm border"
               style={{ background: "hsl(75 100% 47% / 0.1)", borderColor: "hsl(75 100% 47% / 0.2)" }}>
            🏅
          </div>
          <div>
            <div className="font-data text-base font-bold leading-none" style={{ color: LIME }}>{score}</div>
            <div className="font-display text-[0.52rem] text-muted-foreground uppercase tracking-widest mt-0.5">{rank}</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
