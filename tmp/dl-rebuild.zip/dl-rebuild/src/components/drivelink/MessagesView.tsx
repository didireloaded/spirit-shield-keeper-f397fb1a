import { useState, useRef, useEffect } from "react";
import { useChannels, useMessages } from "@/hooks/useMessages";
import { useAuth } from "@/hooks/useAuth";
import { useStore } from "@/store";
import { useVoiceRoom } from "@/hooks/useVoiceRoom";
import { supabase } from "@/integrations/supabase/client";

const LIME  = "hsl(75 100% 47%)";
const BLUE  = "hsl(202 90% 62%)";
const GREEN = "hsl(145 63% 47%)";

export function MessagesView() {
  const channels        = useChannels();
  const [activeChannelId, setActive] = useState<string | null>(null);
  const [voiceRooms, setVoiceRooms]  = useState<any[]>([]);
  const { user }                     = useAuth();
  const { messages, loading, sendMessage } = useMessages(activeChannelId);
  const [input, setInput]            = useState("");
  const bottomRef                    = useRef<HTMLDivElement>(null);
  const showNotif                    = useStore((s) => s.showNotification);
  const { joinByUrl, voiceActive }   = useVoiceRoom();

  useEffect(() => {
    if (channels.length && !activeChannelId) setActive(channels[0].id);
  }, [channels, activeChannelId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    supabase.from("voice_rooms").select("*").eq("is_active", true)
      .order("created_at", { ascending: false })
      .then(({ data }) => { if (data) setVoiceRooms(data); });

    const ch = supabase.channel("voice-rooms-feed")
      .on("postgres_changes", { event: "*", schema: "public", table: "voice_rooms" }, () => {
        supabase.from("voice_rooms").select("*").eq("is_active", true)
          .order("created_at", { ascending: false })
          .then(({ data }) => { if (data) setVoiceRooms(data); });
      }).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const handleSend = async () => {
    if (!input.trim()) return;
    await sendMessage(input);
    setInput("");
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div
        className="flex-shrink-0 px-4 md:px-5 pt-5 pb-3 border-b"
        style={{ borderColor: "hsl(60 5% 14%)" }}
      >
        <h2 className="font-display text-xl tracking-wider text-foreground leading-none">Community</h2>
        <p className="font-body text-[0.62rem] text-muted-foreground mt-1">Driver network · Namibia</p>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
        {/* Voice rooms sidebar */}
        {voiceRooms.length > 0 && (
          <div
            className="flex-shrink-0 md:w-56 border-b md:border-b-0 md:border-r"
            style={{ borderColor: "hsl(60 5% 14%)" }}
          >
            <div className="px-4 py-3">
              <p className="font-display text-[0.6rem] tracking-[0.18em] uppercase mb-2 flex items-center gap-2"
                 style={{ color: BLUE }}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: BLUE, animation: "pulse-dot 1.5s infinite", display: "inline-block" }} />
                Live Rooms
              </p>
              <div className="space-y-1.5">
                {voiceRooms.map((room) => (
                  <div
                    key={room.id}
                    className="flex items-center justify-between px-2.5 py-2 rounded border"
                    style={{ background: `${BLUE}0a`, borderColor: `${BLUE}25` }}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-sm flex-shrink-0">🎙</span>
                      <span className="font-body text-[0.68rem] truncate" style={{ color: BLUE }}>{room.name}</span>
                    </div>
                    <button
                      onClick={() => room.daily_room_url
                        ? joinByUrl(room.daily_room_url, room.name)
                        : showNotif("No room URL", "error")}
                      disabled={voiceActive}
                      className="flex-shrink-0 ml-2 font-display text-[0.56rem] tracking-wider px-2.5 py-1 rounded border cursor-pointer transition-all disabled:opacity-40"
                      style={{
                        background:  `${BLUE}15`,
                        borderColor: `${BLUE}35`,
                        color:       BLUE,
                      }}
                    >
                      {voiceActive ? "Live" : "Join"}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-hidden flex flex-col min-w-0">
          <div className="flex-1 overflow-y-auto px-4 py-3 hide-scrollbar">
            {loading ? (
              <p className="font-data text-[0.62rem] text-muted-foreground text-center py-8">LOADING…</p>
            ) : messages.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-2xl mb-2">◈</p>
                <p className="font-body text-xs text-muted-foreground">No messages yet. Start the conversation.</p>
              </div>
            ) : (
              messages.map((msg) => {
                const isOwn = msg.user_id === user?.id;
                return (
                  <div key={msg.id} className={`flex gap-2 mb-3 ${isOwn ? "flex-row-reverse" : "flex-row"}`}>
                    {/* Avatar */}
                    <div
                      className="w-7 h-7 rounded flex-shrink-0 flex items-center justify-center overflow-hidden border"
                      style={{ background: `${LIME}15`, borderColor: `${LIME}25` }}
                    >
                      {msg.profile?.avatar_url
                        ? <img src={msg.profile.avatar_url} className="w-full h-full object-cover" alt="" />
                        : <span className="font-display text-[0.65rem] font-bold" style={{ color: LIME }}>
                            {(msg.profile?.display_name?.[0] ?? "?").toUpperCase()}
                          </span>
                      }
                    </div>

                    <div className={`max-w-[72%] flex flex-col gap-0.5 ${isOwn ? "items-end" : "items-start"}`}>
                      {!isOwn && (
                        <span className="font-display text-[0.52rem] tracking-[0.1em] uppercase text-muted-foreground px-1">
                          {msg.profile?.display_name ?? "Driver"}
                        </span>
                      )}
                      <div
                        className="px-3 py-2 rounded font-body text-[0.76rem] leading-relaxed"
                        style={isOwn
                          ? { background: LIME, color: "hsl(60 8% 5%)", borderBottomRightRadius: "2px" }
                          : { background: "hsl(60 6% 11%)", color: "hsl(60 10% 91%)", border: "1px solid hsl(60 5% 16%)", borderBottomLeftRadius: "2px" }
                        }
                      >
                        {msg.content}
                      </div>
                      <span className="font-data text-[0.5rem] text-muted-foreground px-1">
                        {new Date(msg.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div
            className="flex-shrink-0 flex gap-2 px-4 py-3 border-t"
            style={{ borderColor: "hsl(60 5% 14%)" }}
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Message drivers…"
              className="flex-1 rounded px-3 py-2.5 font-body text-sm text-foreground outline-none placeholder:text-muted-foreground border"
              style={{ background: "hsl(60 6% 9%)", borderColor: "hsl(60 5% 16%)" }}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim()}
              className="rounded px-4 py-2 font-display text-sm tracking-wider border-none cursor-pointer disabled:opacity-30 transition-all"
              style={{ background: LIME, color: "hsl(60 8% 5%)" }}
            >
              →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
