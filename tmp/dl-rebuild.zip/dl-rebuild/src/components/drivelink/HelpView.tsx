import { useState, useCallback, useEffect } from "react";
import { useStore } from "@/store";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useGeolocation } from "@/hooks/useGeolocation";
import { AIChat } from "./AIChat";

const LIME   = "hsl(75 100% 47%)";
const GREEN  = "hsl(145 63% 47%)";
const RED    = "hsl(0 90% 58%)";
const ORANGE = "hsl(30 100% 54%)";

export function HelpView() {
  const showNotif = useStore((s) => s.showNotification);
  const { user }  = useAuth();
  const geo       = useGeolocation();
  const [sosStep, setSosStep] = useState<"idle" | "confirm" | "sent">("idle");
  const [activeSOS, setActiveSOS] = useState<any>(null);

  useEffect(() => {
    const ch = supabase.channel("sos-alerts")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "sos_events" },
        async (payload) => {
          const sos = payload.new as any;
          if (sos.user_id === user?.id) return;
          const { data: profile } = await supabase
            .from("profiles").select("display_name, avatar_url")
            .eq("user_id", sos.user_id).single();
          setActiveSOS({ ...sos, profile });
          showNotif(`🆘 ${profile?.display_name ?? "A driver"} needs help!`, "error");
        }
      ).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [showNotif, user?.id]);

  const handleSOS = useCallback(async () => {
    if (sosStep === "idle") { setSosStep("confirm"); return; }
    setSosStep("sent");
    if (user) {
      await supabase.from("sos_events").insert({
        lat: geo.lat ?? -22.5609, lng: geo.lng ?? 17.0836,
        message: "Emergency SOS activated",
      } as any);
    }
    showNotif("🆘 SOS sent to all nearby drivers!", "error");
    setTimeout(() => setSosStep("idle"), 10000);
  }, [sosStep, user, geo.lat, geo.lng, showNotif]);

  const quickItems = [
    { icon: "🔧", title: "Breakdown",   sub: "Alert nearby drivers",  msg: "Breakdown reported", type: "breakdown" },
    { icon: "🛞", title: "Flat Tyre",   sub: "Share your location",   msg: "Flat tyre — location shared", type: "flat_tyre" },
    { icon: "⛽", title: "Out of Fuel", sub: "Find nearest station",  msg: "Fuel request sent",  type: "fuel" },
    { icon: "🏥", title: "Medical",     sub: "Request assistance",    msg: "Medical emergency — alerting drivers", type: "medical" },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex-shrink-0 px-4 md:px-5 pt-5 pb-3 border-b" style={{ borderColor: "hsl(60 5% 14%)" }}>
        <h2 className="font-display text-xl tracking-wider text-foreground leading-none">Help Me</h2>
        <p className="font-body text-[0.62rem] text-muted-foreground mt-1">Roadside assistance · emergency SOS</p>
      </div>

      <div className="flex-1 overflow-y-auto px-4 md:px-5 pt-3 pb-4 hide-scrollbar">
        <div className="flex flex-col md:flex-row gap-3 max-w-4xl">
          {/* SOS column */}
          <div className="md:flex-1 flex flex-col gap-3">
            {/* Incoming SOS */}
            {activeSOS && (
              <div className="rounded border px-4 py-3 flex items-center gap-3"
                   style={{ background: `${RED}08`, borderColor: `${RED}30`, borderLeft: `3px solid ${RED}` }}>
                <span className="text-2xl">🆘</span>
                <div className="flex-1">
                  <p className="font-body text-sm font-semibold" style={{ color: RED }}>
                    {activeSOS.profile?.display_name ?? "A driver"} needs help!
                  </p>
                  <p className="font-data text-[0.58rem] text-muted-foreground mt-0.5">
                    {new Date(activeSOS.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
                <button onClick={() => setActiveSOS(null)}
                        className="font-body text-xs text-muted-foreground bg-transparent border-none cursor-pointer underline">
                  Dismiss
                </button>
              </div>
            )}

            {/* SOS button */}
            <div
              className="rounded border p-5 text-center"
              style={{
                background:  `${RED}06`,
                borderColor: `${RED}20`,
                borderLeft:  `3px solid ${RED}`,
              }}
            >
              {sosStep === "sent" ? (
                <div className="py-4">
                  <div className="text-5xl mb-3 animate-pulse">📡</div>
                  <p className="font-display text-xl tracking-wider" style={{ color: RED }}>SOS SENT</p>
                  <p className="font-body text-xs text-muted-foreground mt-2">Stay calm and visible. Help is on the way.</p>
                </div>
              ) : (
                <>
                  <div className="text-4xl mb-3">🆘</div>
                  <p className="font-display text-2xl tracking-[0.14em] mb-1" style={{ color: RED }}>EMERGENCY SOS</p>
                  <p className="font-body text-[0.68rem] text-muted-foreground mb-5">
                    Broadcasts your location to all nearby drivers
                  </p>
                  <button
                    onClick={handleSOS}
                    className="w-full rounded py-4 font-display text-xl tracking-[0.18em] uppercase border-none cursor-pointer transition-all"
                    style={{
                      background:  sosStep === "confirm" ? RED : `${RED}15`,
                      color:       sosStep === "confirm" ? "white" : RED,
                      border:      `1px solid ${RED}40`,
                      animation:   sosStep === "confirm" ? "fab-pulse 0.8s infinite" : "none",
                    }}
                  >
                    {sosStep === "confirm" ? "⚠ TAP AGAIN TO CONFIRM" : "ACTIVATE SOS"}
                  </button>
                  {sosStep === "confirm" && (
                    <button
                      onClick={() => setSosStep("idle")}
                      className="mt-2.5 font-body text-xs text-muted-foreground underline bg-transparent border-none cursor-pointer"
                    >
                      Cancel
                    </button>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Quick help */}
          <div className="scard md:flex-1">
            <div className="section-label">Quick Help</div>
            <div className="grid grid-cols-2 gap-2">
              {quickItems.map((item) => (
                <button
                  key={item.type}
                  onClick={async () => {
                    showNotif(item.msg, "success");
                    if (user) {
                      await supabase.from("sos_events").insert({
                        lat: geo.lat ?? -22.5609, lng: geo.lng ?? 17.0836,
                        message: item.msg,
                      } as any);
                    }
                  }}
                  className="rounded border text-center p-3.5 cursor-pointer transition-all active:scale-95"
                  style={{ background: "hsl(60 6% 8%)", borderColor: "hsl(60 5% 15%)" }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.borderColor = `${LIME}30`; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.borderColor = "hsl(60 5% 15%)"; }}
                >
                  <div className="text-2xl mb-2">{item.icon}</div>
                  <div className="font-body text-[0.7rem] text-foreground font-medium">{item.title}</div>
                  <div className="font-body text-[0.58rem] text-muted-foreground mt-0.5">{item.sub}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* AI Assistant */}
        <div className="mt-3 max-w-4xl">
          <AIChat />
        </div>
      </div>
    </div>
  );
}
